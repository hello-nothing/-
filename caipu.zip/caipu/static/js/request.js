const request = function(url, data, method) {
	const baseUrl = 'http://121.36.173.144:19875';
	return new Promise(reslove => {
		uni.showLoading();
		uni.request({
			url: baseUrl + url,
			data,
			method,
			success(res) {
				const data = res.data;
				reslove(res.data)
			},
			fail(err) {
				uni.showToast({
					title: '加载中',
					icon: 'none'
				})
			},
			complete() {
				uni.hideLoading();
			}
		})
	})
}

const API = {
	get(url, data) {
		return request(url, data, 'GET');
	},
	post(url, data) {
		return request(url, data, 'POST');
	},
	// 最新菜谱列表
	newFoodList() {
		const url = '/first/newFoods';
		return this.get(url);
	},
	// 我的上传列表
	myUploadlist(data){
		const url = '/first/myFoods';
		return this.post(url, data);
	},
	// 我的收藏列表
	myFoodlist(data) {
		const url = '/first/myFavority';
		return this.get(url, data);
	},
	// 菜谱详情
	getFoodDetail(data) {
		const url = '/first/detail';
		return this.get(url, data);
	},
	// 点击收藏
	clickConfirm(data) {
		const url = '/first/collection';
		return this.get(url, data);
	},
	// 热门菜谱
	getHotList() {
		const url = '/first/hot';
		return this.get(url);
	},
	// 分类菜谱
	getType(data) {
		const url = '/first/categoryFoods';
		return this.get(url, data);
	},
	// 食材列表
	getHotList(data) {
		const url = '/first/queryByIngredients';
		return this.get(url, data);
	},
	// 早中晚菜谱列表
	getTypeList(data) {
		// const url = '/first/queryByIngredients';
		// return this.get(url, data);
	},
	// 登录接口
	Login(data){
		const url = '/login/login';
		return this.post(url, data)
	},
	// 注册接口
	register(data){
		const url = '/login/passwordResigst';
		return this.post(url, data);
	},
	// 搜索
	search(data){
		const url = '/first/search';
		return this.get(url, data);
	},
	// 上传菜谱
	uploadFood(data){
		const url = '/first/insert';
		return this.post(url, data);
	}
	
}
module.exports = API;
