<template>
	<view class="page-content">
		<view class="pic-food no-image" v-if="image == null">暂无图片</view>
		<view v-else class="pic-food" :style="{ 'background-image': 'url(' + imageUrl + image + ')' }"></view>
		<view class="food-container">
			<view class="food-title">{{ title }}</view>
			<view class="food-words">{{ words }}</view>
			<view class="model-cont">
				<view class="title-tip">用料</view>
				<view class="materials-tip">{{ materialsDetail }}</view>
			</view>
			<view class="model-cont">
				<view class="title-tip">做法</view>
				<view class="step-word">第一步：{{ messureList.one }}</view>
				<view class="step-word">第二步：{{ messureList.two }}</view>
				<view class="step-word">第三步：{{ messureList.three }}</view>
				<view class="step-word">第四步：{{ messureList.four }}</view>
				<view class="step-word">第五步：{{ messureList.five }}</view>
			</view>
		</view>
		<view class="button" v-if="confirm" @tap="cilckConfirm">收藏菜谱</view>
		<view class="button cancel" v-if="!confirm">已收藏</view>
	</view>
</template>

<script>
	import API from '../../static/js/request.js';
	import {
		mapState,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				imageUrl: 'http://q8pqctivi.bkt.clouddn.com/',
				image: '',
				pic: '/static/img/jiachang.jpg',
				title: '暂无数据',
				words: '暂无数据',
				dataList: [{
						title: '五花肉',
						num: '500克'
					},
					{
						title: '暂无数据',
						num: '暂无数据'
					},
					{
						title: '暂无数据',
						num: '暂无数据'
					}
				],
				messureList: {
					one: '', 
					two: '',
					three: '',
					four: '',
					five: '',
				},
				messure: '暂无数据',
				confirm: true,
				cancel: false,
				materialsDetail: '暂无数据',
				foodId: '',
				userID: ''
			};
		},
		computed: {
			...mapState(['hasLogin', 'forcedLogin'])
		},
		onLoad: function(option) {
			//option为object类型，会序列化上个页面传递的参数
			console.log(option); //打印出上个页面传递的参数。
			this.foodId = option.foodid;
			let value = uni.getStorageSync('userid');
			if (value) {
				console.log(value);
				this.userID = value;
			}
			const params = {
				foodsId: option.foodid
			};
			// 请求菜谱的详情接口
			API.getFoodDetail(params).then(res => {
				console.log('菜谱详情', res);
				if (res.code === 200) {
					this.title = res.data.name;
					this.materialsDetail = res.data.step;
					this.image = res.data.image;
					this.messureList = res.data;
					console.log(this.messureList)
					// this.messureList.forEach(function(element) {
					// 	console.log(element)
					// 	// element.messure = res.data.one;
					// });
				}
			});
		},
		methods: {
			// 点击收藏
			cilckConfirm() {
				console.log(this.hasLogin)
				if (!this.hasLogin) {
					uni.showModal({
						title: '未登录',
						content: '收藏菜谱前请先登录！',
						// showCancel:false
						success: function(res) {
							if (res.confirm) {
								console.log('用户点击确定');
								uni.navigateTo({
									url: '../login/login'
								})
							} else if (res.cancel) {
								console.log('用户点击取消');
							}
						}
					})
				} else {
					const params = {
						foodsId: this.foodId,
						userId: this.userID
					}
					API.clickConfirm(params).then(res => {
						console.log(res)
						if (res.code === 200) {
							uni.showToast({
								title: '收藏成功',
								duration: 2000
							});
							this.confirm = false;
						}
					})
				}
			}
		}
	};
</script>

<style lang="scss">
	.page-content {
		position: relative;
		width: 100%;
	}

	.no-image {
		background-color: #979797;
	}

	.pic-food {
		width: 100%;
		height: 400rpx;
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.food-container {
		// height: 100%;
		padding: 30rpx;
		padding-bottom: 100px;
	}

	.food-title {
		font-size: 50rpx;
		font-weight: bold;
	}

	.food-words {
		padding-top: 20rpx;
		font-size: 40rpx;
	}

	.model-cont {
		padding-top: 30rpx;
	}

	.title-tip {
		padding-bottom: 30rpx;
		font-size: 45rpx;
		font-weight: bold;
	}

	.food-cont {
		font-size: 38rpx;
	}
	.step-word {
		padding-bottom: 24rpx;;
	}

	.button {
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 100rpx;
		line-height: 100rpx;
		font-size: 38rpx;
		text-align: center;
		background-color: #87cfb5;
	}

	.cancel {
		background-color: #55aa7f;
	}
</style>
