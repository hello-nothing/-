<template>
	<view class="three-content">
		<scroll-view scroll-y="true" class="nav-box clearfix">
			<view
				class="nav-list pull-left"
				v-for="item in navList"
				:key="item.id"
				:class="{ 'scroll-bar-itemsh': current == item.current }"
				:id="item.id"
				:data-current="item.current"
				@tap="fnBarClick(item)"
			>
				{{ item.name }}
			</view>
		</scroll-view>
		<swiper class="swiper-box" :current="current" @change="fnBarClick">
			<swiper-item class="s-list">
				<view class="food-list" v-for="(item, index) in detailList" :key="index">
					<view @click="goDetail(item.id)">
						<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
						<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
						<view class="food-word pull-left">
							<view class="food-title">{{ item.name }}</view>
							<view class="food-main">{{ item.username }}</view>
						</view>
					</view>
				</view>
				<view class="no-data" v-if="noData">暂无数据</view>
			</swiper-item>
			<swiper-item class="s-list">
				<view class="food-list" v-for="(item, index) in detailList" :key="index">
					<view @click="goDetail(item.id)">
						<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
						<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
						<view class="food-word pull-left">
							<view class="food-title">{{ item.name }}</view>
							<view class="food-main">{{ item.username }}</view>
						</view>
					</view>
				</view>
				<view class="no-data" v-if="noData">暂无数据</view>
			</swiper-item>
			<swiper-item class="s-list">
				<view class="food-list" v-for="(item, index) in detailList" :key="index">
					<view @click="goDetail(item.id)">
						<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
						<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
						<view class="food-word pull-left">
							<view class="food-title">{{ item.name }}</view>
							<view class="food-main">{{ item.username }}</view>
						</view>
					</view>
				</view>
				<view class="no-data" v-if="noData">暂无数据</view>
			</swiper-item>
		</swiper>
	</view>
</template>

<script>
import API from '../../static/js/request.js';

export default {
	data() {
		return {
			scrollInto: 'all',
			// 顶部导航滑动页选中
			current: 0,
			status: {
				all: true,
				album: false,
				video: false,
				word: false
			},
			noData: false,
			navList: [
				{
					id: 'all',
					name: '早餐',
					current: 0
				},
				{
					id: 'album',
					name: '午餐',
					current: 1
				},
				{
					id: 'video',
					name: '晚餐',
					current: 2
				}
			],
			statuscode: '',
			detailList: [],
			imageUrl: 'http://q8pqctivi.bkt.clouddn.com/'
		};
	},
	methods: {
		// 跳转至详情页
		goDetail: function(foodid) {
			console.log(foodid);
			uni.navigateTo({
				url: '../detail-page/detail-page?foodid=' + foodid
			});
		},
		// 点击顶部tab
		fnBarClick(e) {
			let current = e.hasOwnProperty('detail') ? e.detail.current : e.current;
			this.scrollInto = this.navList[current].id;
			// 是否当前项点击
			if (e.hasOwnProperty('id') && this.current == current) {
				this.timeOutCollection += 1;
				// 是否为刷新值和连续触发
				if (!this.clickRefresh && this.timeOutCollection >= 2) {
					// 刷新值开
					this.clickRefresh = true;
					// 获取新数据
					this.fnRefreshData();
					// 定时器重置
					this.timeOutCollection = setTimeout(() => {
						// 清除定时器
						clearTimeout(this.timeOutCollection);
						// 连续触发记录重置
						this.timeOutCollection = 0;
						// 刷新值关
						this.clickRefresh = false;
					}, 5000);
				}
				return;
			} else {
				// 改变顶部导航选中
				this.current = current;
				this.statuscode = this.current + 1;
				console.log(this.statuscode);
				this.getfoodlist();
				// 首次选中激活顶部导航关联页状态
				if (!this.status.album && current == 1) this.status.album = true;
				if (!this.status.video && current == 2) this.status.video = true;
				if (!this.status.word && current == 3) this.status.word = true;
				// 清除定时器
				clearTimeout(this.timeOutCollection);
				// 连续触发记录重置
				this.timeOutCollection = 0;
				// 刷新值关
				this.clickRefresh = false;
			}
		},
		getfoodlist: function() {
			const status = JSON.stringify(this.statuscode);
			uni.request({
				url: 'http://121.36.173.144:19875/first/threeFoods?status=' + this.statuscode,
				data: {
					status: this.statuscode
				},
				method: 'POST',
				success: res => {
					console.log(res);
					this.detailList = res.data;
				}
			});
			if (this.detailList.length == 0) {
				this.noData = true;
			}
		},
		onPullDownRefresh: function(){
			console.log('下拉加载更多数据')
		},
		onReachBottom: function(e){
			console.log('触底加载')
		}
	},
	onLoad(option) {
		this.statuscode = 1;
		this.getfoodlist();
	},
	onShow() {}
};
</script>

<style lang="scss">
	page{
		height: 100%;
	}
.three-content {
	position: relative;
	width: 100%;
	height: 100%;
	padding-top: 30rpx;
}

.swiper-box {
	width: 100%;
	// height: 100%;
	height: 3000rpx;
}

.nav-box {
	// position: absolute;
	top: 100rpx;
	// border-bottom: 4rpx solid #999;
}

.nav-list {
	width: calc(100% / 3);
	padding-bottom: 20rpx;
	text-align: center;
}

.scroll-bar-itemsh {
	border-bottom: 4rpx solid #87cfb5;
}
.food-list {
	height: 200rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
	background-color: #fff;
	border-radius: 8px;
}

.food-image {
	width: 300rpx;
	height: 200rpx;
	background-color: #87cfb5;
	background-repeat: no-repeat;
	background-position: center;
	background-size: cover;
}

.food-word {
	width: calc(100% - 330rpx);
	padding-left: 30rpx;
}

.food-title {
	font-size: 40rpx;
}

.food-main {
	padding-top: 20rpx;
	font-size: 32rpx;
	color: #666;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}
</style>
