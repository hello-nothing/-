<template>
	<view class="detail-content">
		<view class="food-list" v-for="(item, index) in detailList" :key="index">
			<view @click="goDetail(item.id)">
				<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
				<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
				<view class="food-word pull-left">
					<view class="food-title">{{ item.name }}</view>
					<view class="food-main">{{ item.username }}</view>
				</view>
			</view>
		</view>
		<view class="no-data" v-if="noData">暂无上传数据</view>
	</view>
</template>

<script>
	import API from '../../static/js/request.js';

	export default {
		data() {
			return {
				detailList: [],
				imageUrl: 'http://q8pqctivi.bkt.clouddn.com/',
				pageSize: 10,
				currentPage: 1,
				uid: '',
				noData: false
			};
		},
		methods: {
			// 获取上传菜谱的列表数据
			getlist: function() {
				const params = {
					pageSize: this.pageSize,
					currentPage: this.currentPage,
					uid: this.uid
				};
				uni.request({
					url: 'http://121.36.173.144:19875/first/myFoods?pageSize=' + this.pageSize + '&currentPage=' + this.currentPage +
						'&uid=' + this.uid,
					method: 'POST',
					success: res => {
						console.log(res);
						if (res.data.code == 200) {
							this.detailList = res.data.data;
							if (this.detailList.length == 0) {
								this.noData = true;
							}
						} else {
							uni.showToast({
								title:'查询失败,请稍后尝试',
								duration:3000
							})
						}
					}
				});
			},
			// 跳转至详情页面
			goDetail: function(foodid) {
				console.log(foodid);
				uni.navigateTo({
					url: '../detail-page/detail-page?foodid=' + foodid
				});
			}
		},
		onLoad() {
			let value = uni.getStorageSync('userid');
			if (value) {
				console.log(value);
				this.uid = value;
				this.getlist();
			}
		}
	};
</script>

<style lang="scss">
	page {
		background-color: #efeff4;
	}

	.detail-content {
		width: 100%;
		// padding: 20rpx 25rpx;
	}

	.food-list {
		height: 200rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		background-color: #fff;
		// border-radius: 8px;
	}

	.food-image {
		width: 300rpx;
		height: 200rpx;
		background-color: #87cfb5;
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.food-word {
		width: calc(100% - 330rpx);
		padding-left: 30rpx;
	}

	.food-title {
		font-size: 40rpx;
	}

	.food-main {
		padding-top: 20rpx;
		font-size: 32rpx;
		color: #666;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
</style>
