<template>
	<view class="content">
		<view class="input-group">
			<view class="input-row border">
				<text class="title">账号：</text>
				<m-input type="text" focus clearable v-model="account" placeholder="请输入账号"></m-input>
			</view>
			<view class="input-row border">
				<text class="title">密码：</text>
				<m-input type="password" displayable v-model="password" placeholder="请输入密码"></m-input>
			</view>
			<!-- <view class="input-row">
				<text class="title">邮箱：</text>
				<m-input type="text" clearable v-model="email" placeholder="请输入邮箱"></m-input>
			</view> -->
		</view>
		<view class="btn-row"><button type="primary" class="primary" @tap="register">注册</button></view>
	</view>
</template>

<script>
	import service from '../../service.js';
	import mInput from '../../components/m-input.vue';
	import API from '../../static/js/request.js';

	export default {
		components: {
			mInput
		},
		data() {
			return {
				account: '',
				password: '',
				email: ''
			};
		},
		methods: {
			register() {

				if (this.account.length < 5) {
					uni.showToast({
						icon: 'none',
						title: '账号最短为 5 个字符'
					});
					return;
				}
				if (this.password.length < 6) {
					uni.showToast({
						icon: 'none',
						title: '密码最短为 6 个字符'
					});
					return;
				}
				let data = {
					username: this.account,
					password: this.password
					// email: this.email
				};
				console.log(data, '222222')
				API.register(data).then(res => {
					console.log('注册信息返回', res)
					if (res.code === 200) {
						service.addUser(data);
						uni.showToast({
							title: '注册成功',
							duration: 2000
						});
						uni.navigateBack({
							delta: 1
						});
					}
					if (res.code === 201) {
						uni.showToast({
							title: '用户名已经存在'
						});
					}
				})
			}
		}
	};
</script>

<style></style>
