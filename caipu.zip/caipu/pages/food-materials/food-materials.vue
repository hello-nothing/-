<template>
	<view class="food-content clearfix">
		<view class="side-box pull-left">
			<scroll-view scroll-y="true" class="nav-box">
				<view class="nav-list" v-for="item in navList" :key="item.id" :class="{ 'scroll-bar-itemsh': current == item.current }"
				 :id="item.id" :data-current="item.current" @tap="fnBarClick(item)">
					{{ item.name }}
				</view>
			</scroll-view>
		</view>
		<view class="message-box pull-right">
			<swiper class="swiper-box" :current="current" @change="fnBarClick">
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
				<swiper-item class="s-list">
					<view class="food-list" v-for="(item, index) in detailList" :key="index">
						<view @click="goDetail(item.id)">
							<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
							<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
							<view class="food-word pull-left">
								<view class="food-title">{{ item.name }}</view>
								<view class="food-main">{{ item.username }}</view>
							</view>
						</view>
					</view>
					<view class="no-data" v-if="noData">暂无数据</view>
				</swiper-item>
			</swiper>
		</view>
	</view>
</template>

<script>
	import API from '../../static/js/request.js';

	export default {
		data() {
			return {
				scrollInto: 'all',
				// 顶部导航滑动页选中
				current: 0,
				status: {
					one: true,
					two: false,
					three: false,
					four: false,
					five: false,
					// word: false,
				},
				noData: false,
				navList: [{
						id: 'one',
						name: '鸡肉',
						current: 0
					},
					{
						id: 'two',
						name: '木耳',
						current: 1
					},
					{
						id: 'three',
						name: '鱼肉',
						current: 2
					},
					{
						id: 'four',
						name: '虾',
						current: 3
					},
					{
						id: 'five',
						name: '豆腐',
						current: 4
					}
				],
				currentPage: 1,
				pageSize: 4,
				ingredients: '',
				detailList: [],
				imageUrl: 'http://q8pqctivi.bkt.clouddn.com/', // 图片地址
			};
		},
		methods: {

			// 点击跳转至页面详情页
			goDetail: function(foodid) {
				console.log(foodid);
				uni.navigateTo({
					url: '../detail-page/detail-page?foodid=' + foodid
				});
			},
			// 获取食材列表
			getList: function() {
				const params = {
					currentPage: this.currentPage,
					pageSize: this.pageSize,
					ingredients: this.ingredients
				}
				API.getHotList(params).then(res => {
					console.log('食材列表', res)
					this.detailList = res;
					console.log(this.detailList.length)
					if (this.detailList.length === 0) {
						this.noData = false;
					}
				})
				
			},
			fnBarClick(e) {
				let current = e.hasOwnProperty('detail') ? e.detail.current : e.current;
				this.scrollInto = this.navList[current].id;
				this.ingredients = this.navList[current].name;
				// this.ingredients =  JSON.stringify(ingredients)
				console.log(this.ingredients);
				this.getList();
				// 是否当前项点击
				if (e.hasOwnProperty('id') && this.current == current) {
					this.timeOutCollection += 1;
					// 是否为刷新值和连续触发
					if (!this.clickRefresh && this.timeOutCollection >= 2) {
						// 刷新值开
						this.clickRefresh = true;
						// 获取新数据
						this.fnRefreshData();
						// 定时器重置
						this.timeOutCollection = setTimeout(() => {
							// 清除定时器
							clearTimeout(this.timeOutCollection);
							// 连续触发记录重置
							this.timeOutCollection = 0;
							// 刷新值关
							this.clickRefresh = false;
						}, 5000);
					}
					return;
				} else {
					// 改变顶部导航选中
					this.current = current;
					// 首次选中激活顶部导航关联页状态
					if (!this.status.one && current == 0) this.status.one = true;
					if (!this.status.two && current == 1) this.status.two = true;
					if (!this.status.three && current == 2) this.status.three = true;
					if (!this.status.four && current == 3) this.status.four = true;
					if (!this.status.five && current == 4) this.status.five = true;
					// 清除定时器
					clearTimeout(this.timeOutCollection);
					// 连续触发记录重置
					this.timeOutCollection = 0;
					// 刷新值关
					this.clickRefresh = false;
				}
			}
		},
		onLoad(option) {
			this.ingredients = this.ingredients = this.navList[0].name;
			if (this.ingredients != '') {
				this.getList();
			}
		}
	};
</script>

<style lang="scss">
	page {
		background-color: #f5f5f5;
	}

	.food-content {
		width: 100%;
		padding-top: 40rpx;
	}

	.side-box {
		width: 20%;
		font-size: 40rpx;
		text-align: center;
		background-color: #87cfb5;
		// position: absolute;
	}

	.nav-list {
		height: 100rpx;
		padding: 10rpx 0;
		line-height: 100rpx;

		&:hover {
			background-color: #10ad82;
		}
	}

	.nav-box {
		width: 100%;
	}

	.message-box {
		width: 75%;
		// height: 100%;
		height: 1600rpx;
		padding-right: 20rpx;
	}

	.swiper-box {
		height: 100%;
	}

	.food-list {
		height: 200rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		background-color: #fff;
		border-radius: 8px;
	}

	.food-image {
		width: 300rpx;
		height: 200rpx;
		background-color: #87cfb5;
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.food-word {
		width: calc(100% - 330rpx);
		padding-left: 30rpx;
	}

	.food-title {
		font-size: 40rpx;
	}

	.food-main {
		padding-top: 20rpx;
		font-size: 32rpx;
		color: #666;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
</style>
