<template>
	<view class="content">
		<view class="container" v-if="hasLogin">
			<navigator class="my-food" url="../my-food/my-food">我的收藏</navigator>
			<navigator class="my-food" url="../upload-food/upload-food">上传菜谱</navigator>
			<navigator class="my-food" url="../my-upload/my-upload">我的上传</navigator>
		</view>
		<view class="btn-row">
			<button v-if="!hasLogin" type="primary" class="primary" @tap="bindLogin">登录</button>
			<button v-if="hasLogin" type="default" @tap="bindLogout">退出登录</button>
		</view>
		<view class="words" v-if="!hasLogin">登录后即可上传和收藏喜欢的菜品</view>
	</view>
</template>

<script>
	import {
		mapState,
		mapMutations
	} from 'vuex';
	import API from '../../static/js/request.js';

	export default {
		computed: {
			...mapState(['hasLogin', 'forcedLogin'])
		},
		methods: {
			...mapMutations(['logout']),
			// 跳转至登录页面
			bindLogin() {
				uni.navigateTo({
					url: '../login/login'
				});
			},
			bindLogout() {
				this.logout();
				/**
				 * 如果需要强制登录跳转回登录页面
				 */
				if (this.forcedLogin) {
					uni.reLaunch({
						url: '../login/login'
					});
				}
			}
		}
	};
</script>

<style lang="scss">
	.words {
		padding-top: 200rpx;
		font-size: 38rpx;
		text-align: center;
	}

	.container {
		padding: 0 20rpx;
		padding-top: 200rpx;
	}

	.my-food {
		width: 100%;
		height: 92rpx;
		margin-bottom: 50rpx;
		line-height: 92rpx;
		text-align: center;
		background-color: #87cfb5;
		border-radius: 8rpx;
	}

	.primary {
		background-color: #87CFB5;
	}
</style>
