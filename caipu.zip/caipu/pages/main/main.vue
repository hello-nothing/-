<template>
	<view class="main-content">
		<navigator url="../search/search" class="search-link clearfix">
			<view class="search pull-left">请输入菜名/食材</view>
			<view class="search-text pull-right">点击搜索</view>
		</navigator>
		<view class="three-food clearfix">
			<navigator url="../three-food/three-food?title=早餐" class="list-food first pull-left">早餐</navigator>
			<navigator url="../three-food/three-food?title=午餐" class="list-food pull-left">午餐</navigator>
			<navigator url="../three-food/three-food?title=晚餐" class="list-food three pull-left">晚餐</navigator>
		</view>
		<view class="recommond-content">
			<view class="hot-title">热门推荐</view>
			<view class="re-list clearfix">
				<view @click="goHot(item.id)" v-for="(item, index) in dataList" :key="index" class="list-cont pull-left">
					<view class="pic-list" :style="{ 'background-image': 'url(' + item.pic + ')' }"></view>
					<view class="list-text">{{ item.name }}</view>
				</view>
			</view>
		</view>
		<view class="recommond-content">
			<view class="hot-title">最新推荐</view>
			<view class="food-list" v-for="(item, index) in detailList" :key="index">
				<view @click="goDetail(item.id)">
					<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
					<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
					<view class="food-word pull-left">
						<view class="food-title">{{ item.name }}</view>
						<view class="food-main">{{ item.username }}</view>
					</view>
				</view>
			</view>
			<view class="super-data" v-if="noData">暂无最新推荐</view>
		</view>
	</view>
</template>

<script>
import { mapState } from 'vuex';
import API from '../../static/js/request.js';

export default {
	data() {
		return {
			dataList: [
				{
					id: 1,
					pic: '/static/img/jiachang.jpg',
					name: '家常菜'
				},
				{
					id: 2,
					pic: '/static/img/sucai.jpg',
					name: '素菜'
				},
				{
					id: 3,
					pic: '/static/img/liangcai.jpg',
					name: '凉菜'
				},
				{
					id: 4,
					pic: '/static/img/tangcai.jpg',
					name: '汤菜'
				},
				{
					id: 5,
					pic: '/static/img/chuangyi.jpg',
					name: '创意菜'
				},
				{
					id: 6,
					pic: '/static/img/recai.jpg',
					name: '热菜'
				},
				{
					id: 7,
					pic: '/static/img/chuancai.jpg',
					name: '川菜'
				},
				{
					id: 8,
					pic: '/static/img/dongbei.jpg',
					name: '东北菜'
				}
			],
			detailList: [],
			imageUrl: 'http://q8pqctivi.bkt.clouddn.com/',
			noData: false
		};
	},
	methods: {
		// 跳转至菜谱详情页
		goDetail: function(foodid) {
			console.log(foodid);
			uni.navigateTo({
				url: '../detail-page/detail-page?foodid=' + foodid
			});
		},
		// 跳转至热门菜谱
		goHot: function(id) {
			uni.navigateTo({
				url: '../food-detail/food-detail?id=' + id
			});
		}
	},
	computed: mapState(['forcedLogin', 'hasLogin', 'userName']),
	onLoad() {
		// 加载最新推荐菜谱列表
		API.newFoodList().then(res => {
			console.log(res);
			this.detailList = res;
		});
		if (this.detailList.length == 0) {
			this.noData = true;
		}
	}
};
</script>

<style lang="scss">
.main-content {
	width: 100%;
	padding: 0 20rpx;
	padding-top: 30rpx;
	/* background-color: #0FAEFF; */
}

.search-link {
	height: 60rpx;
	margin-bottom: 40rpx;
	line-height: 60rpx;
	border: 1px solid #87cfb5;
	border-radius: 10px;
}

.search {
	width: calc(100% - 300rpx);
	height: 60rpx;
	line-height: 60rpx;
	padding: 0 20rpx;
	color: #c8c7cc;
}

.search-text {
	width: 200rpx;
	border-top-right-radius: 10rpx;
	border-bottom-right-radius: 10rpx;
	text-align: center;
	background-color: #87cfb5;
	color: #fff;
}

.re-list {
	/* display: flex;
		flex: 1;
		flex-direction: column; */
	font-size: 16rpx;
}

.list-cont {
	width: calc(100% / 4);
	margin-bottom: 40rpx;
	text-align: center;
}

.pic-list {
	width: 160rpx;
	height: 50px;
	background-repeat: no-repeat;
	background-position: center;
	background-size: cover;
	border-radius: 20rpx;
}

.hot-title {
	position: relative;
	padding-left: 30rpx;
	margin-bottom: 30rpx;
	font-size: 40rpx;
	color: #87cfb5;

	&:before {
		position: absolute;
		top: 10rpx;
		left: 10rpx;
		width: 6rpx;
		height: 40rpx;
		background-color: #87cfb5;
		content: '';
	}
}

.list-text {
	font-size: 32rpx;
}

.three-food {
	margin-bottom: 40rpx;
}

.list-food {
	width: calc((100% - 140rpx) / 3);
	height: 100rpx;
	padding: 0 20rpx;
	margin-right: 10rpx;
	line-height: 100rpx;
	font-size: 40rpx;
	color: #333;
	text-align: center;
	background-color: #f9beb5;
	border-radius: 20rpx;

	&:last-child {
		margin-right: 0;
	}
}

.first {
	background-color: #f8f4bb;
}

.three {
	background-color: #d0f8fc;
}

.ul {
	font-size: 30upx;
	color: #8f8f94;
	margin-top: 50upx;
}

.ul > view {
	line-height: 50upx;
}

.food-list {
	height: 200rpx;
	padding: 20rpx;
	margin-bottom: 20rpx;
	background-color: #fff;
	border-radius: 8px;
}

.food-image {
	width: 300rpx;
	height: 200rpx;
	background-color: #87cfb5;
	background-repeat: no-repeat;
	background-position: center;
	background-size: cover;
}

.food-word {
	width: calc(100% - 330rpx);
	padding-left: 30rpx;
}

.food-title {
	font-size: 40rpx;
}

.food-main {
	padding-top: 20rpx;
	font-size: 32rpx;
	color: #666;
	overflow: hidden;
	text-overflow: ellipsis;
	display: -webkit-box;
	-webkit-line-clamp: 2;
	-webkit-box-orient: vertical;
}

.super-data {
	text-align: center;
	font-size: 32rpx;
}
</style>
