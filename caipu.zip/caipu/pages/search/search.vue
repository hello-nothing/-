<template>
	<view class="search-content">
		<view class="search-link clearfix">
			<input @input="searchInput" class="search pull-left" placeholder="请输入菜名/食材" confirm-type="search" />
			<view class="search-text pull-right">点击搜索</view>
		</view>
		<!-- <view v-if="hasResult" class="hot-search">
			<view class="hot-title">热门搜索</view>
			<view class="clearfix">
				<view class="hot-item pull-left" v-for="(item, index) in hotList" :key="index">{{ item.name }}</view>
			</view>
		</view>
		<view v-if="hasResult" class="hot-search">
			<view class="hot-title">历史记录</view>
			<view class="clearfix">
				<view class="hot-item pull-left" v-for="(item, index) in hotList" :key="index">{{ item.name }}</view>
			</view>
		</view> -->
		<view v-if="!hasResult" class="detail-content">
			<view class="food-list clearfix" v-for="(item, index) in detailList" :key="index" @click="goDetail(item.id)">
				<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
				<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
				<view class="food-word pull-left">
					<view class="food-title">{{ item.name }}</view>
					<view class="food-main">{{ item.username }}</view>
				</view>
			</view>
			<view class="no-data" v-if="noData">暂无收藏数据</view>
		</view>
	</view>
</template>

<script>
	import API from '../../static/js/request.js';

	export default {
		data() {
			return {
				// hotList: [{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	},
				// 	{
				// 		name: '早饭'
				// 	}
				// ],
				hasResult: true,
				detailList: [],
				Image: '../static/img/dongbei.jpg',
				imageUrl: 'http://q8pqctivi.bkt.clouddn.com/',
				noData: false
			};
		},
		methods: {
			// 查询菜谱方法
			searchInput: function(event) {
				this.inputValue = event.target.value;
				const param = {
					foodsName: event.target.value
				}
				API.search(param).then(res => {
					console.log('搜索信息返回', res)
					if (res.length > 0) {
						this.hasResult = false;
						this.detailList = res;
					} else {
						this.noData = true;
					}
				})
			},
			// 点击跳转至页面详情页
			goDetail: function(foodid) {
				console.log(foodid);
				uni.navigateTo({
					url: '../detail-page/detail-page?foodid=' + foodid
				});
			}

		},
		onLoad() {
			// 页面进入时加载列表数据
			const param = {
				foodsName: ''
			}
			API.search(param).then(res => {
				console.log('未搜索前数据返回', res)
				if (res.length > 0) {
					this.hasResult = false;
					this.detailList = res;
				} else {
					this.noData = true;
				}
			})
		}
	};
</script>

<style lang="scss">
	.search-content {
		width: 100%;
		padding: 20rpx;
	}

	.search-link {
		height: 60rpx;
		margin-bottom: 40rpx;
		line-height: 60rpx;
		border: 1px solid #87cfb5;
		border-radius: 10px;
	}

	.search {
		width: calc(100% - 300rpx);
		height: 60rpx;
		line-height: 60rpx;
		padding: 0 20rpx;
		// color: #C8C7CC;
	}

	.search-text {
		width: 200rpx;
		border-top-right-radius: 10rpx;
		border-bottom-right-radius: 10rpx;
		text-align: center;
		background-color: #87cfb5;
		color: #fff;
	}

	.hot-search {
		margin-bottom: 40rpx;
	}

	.hot-title {
		position: relative;
		padding-left: 30rpx;
		margin-bottom: 30rpx;
		font-size: 32rpx;
		color: #87cfb5;

		&:before {
			position: absolute;
			top: 8rpx;
			left: 10rpx;
			width: 6rpx;
			height: 32rpx;
			background-color: #87cfb5;
			content: '';
		}
	}

	.hot-item {
		width: calc((100% - 100rpx) / 4);
		height: 50rpx;
		line-height: 50rpx;
		margin-right: 20rpx;
		margin-bottom: 30rpx;
		font-size: 32rpx;
		text-align: center;
		color: #666;
		border: 1px solid #87cfb5;
		border-radius: 10rpx;

		&:nth-child(4n) {
			margin-right: 0;
		}
	}

	.detail-content {
		width: 100%;
		padding: 20rpx 25rpx;
	}

	.food-list {
		height: 200rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		background-color: #fff;
		border-radius: 8px;
	}

	.food-image {
		width: 300rpx;
		height: 200rpx;
		background-color: #abcfbf;
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.food-word {
		width: calc(100% - 330rpx);
		padding-left: 30rpx;
	}

	.food-title {
		font-size: 40rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.food-main {
		padding-top: 20rpx;
		font-size: 32rpx;
		color: #666;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
</style>
