<template>
	<view class="upload-content">
		<form @submit="formSubmit" enctype="multipart/form-data">
			<view class="upload-container">
				<view class="picture-content">
					<view class="text-upload">上传成品菜图片：(必填)</view>
					<view class="body-view">
						<view class="uploads">
							<view class="upload-image-view">
								<block v-for="(image, index) in imageList" :key="index">
									<view class="image-view">
										<image :src="image" :data-src="image" @tap="previewImage"></image>
										<view class="del-btn" :data-index="index" @tap="deleteImage">
											<view class="baicha"></view>
										</view>
									</view>
								</block>
								<view class="add-view" v-if="imageList.length < imageLength" @tap="chooseImage">
									<view class="cross">
										<view class="transverse-line"></view>
										<view class="vertical-line"></view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="picture-content">
					<view class="text-upload">上传菜名:</view>
					<input name="name" class="food-input step-food" type="text" value="" placeholder="输入菜名" />
				</view>
				<view class="picture-content">
					<view class="text-upload">上传主要材料:</view>
					<view class="materials-word uni-textarea">
						<textarea maxlength="1000" auto-height class="in-materials" type="text" name="materials" value="" placeholder="输入菜品的主要材料:" />
						</view>
				</view>
				<view class="picture-content">
					<view class="text-upload">上传主要步骤：</view>
					<view class="">
						<input name="stepOne" class="food-input step-food" type="text" value="" placeholder="输入步骤一" />
						<input name="stepTwo" class="food-input step-food" type="text" value="" placeholder="输入步骤二" />
						<input name="stepThree" class="food-input step-food" type="text" value="" placeholder="输入步骤三" />
						<input name="stepFour" class="food-input step-food" type="text" value="" placeholder="输入步骤四" />
						<input name="stepFive" class="food-input step-food" type="text" value="" placeholder="输入步骤五" />
					</view>
				</view>
			</view>
			<view class="submit-content"><button form-type="submit" class="submit">提交</button></view>
		</form>
	</view>
</template>

<script>
import API from '../../static/js/request.js';

var sourceType = [
	['camera'], //拍照
	['album'], //相册
	['camera', 'album'] //拍照或相册
];
var sizeType = [
	['compressed'], //压缩
	['original'], //原图
	['compressed', 'original'] //压缩或原图
];
export default {
	data() {
		return {
			imagePicture: '',
			urls: '',
			imageList: [], //保存图片路径集合
			imageLength: 1, //限制图片张数
			sourceTypeIndex: 2, //添加方式限制
			sizeTypeIndex: 2, //图片尺寸限制，
			materialsImgList: [], //保存菜品材料图片集合
			materialsLength: 3, //限制菜品材料图片张数
			id: '',
			imgUrl:''
		};
	},
	methods: {
		//选择图片
		chooseImage: async function() {
			uni.chooseImage({
				sourceType: sourceType[this.sourceTypeIndex],
				// #ifdef MP-WEIXIN
				sizeType: sizeType[this.sizeTypeIndex],
				// #endif
				count: this.imageLength - this.imageList.length,
				success: res => {
					console.log(res);
					this.imageList = this.imageList.concat(res.tempFilePaths);
					uni.uploadFile({
						// 上传图片接口
						url: 'http://121.36.173.144:19875/first/addPic',
						filePath: res.tempFilePaths[0],
						name: 'filename',
						formData: {
							filename: res.tempFiles[0].name
						},
						success: uploadFileRes => {
							console.log(uploadFileRes.data);
							const data = JSON.parse(uploadFileRes.data)
							console.log(data)
							this.imgUrl = data.data;
							uni.showToast({
								title: '上传图片成功',
								duration: 1000
							});
						}
					});
				}
			});
		},
		//预览图片
		previewImage: function(e) {
			var current = e.target.dataset.src;
			uni.previewImage({
				current: current,
				urls: this.imageList
			});
		},
		//删除图片
		deleteImage: function(e) {
			var index = e.target.dataset.index;
			var that = this;
			var images = that.imageList;
			images.splice(index, 1);
			that.imageList = images;
		},
		// 上传菜谱，提交数据
		formSubmit: function(e) {
			console.log('form发生了submit事件，携带数据为：' + JSON.stringify(e.detail.value));
			var formdata = e.detail.value;
			const params = {
				// 上传图片需要的参数
				name: formdata.name,
				uid: this.id,
				image: this.imgUrl,
				count: 0,
				step: formdata.materials,
				categoryId: '5',
				createTime: '2020-03-05T10:22:10.000+0000',
				one: formdata.stepOne,
				two: formdata.stepTwo,
				three: formdata.stepThree,
				four: formdata.stepFour,
				five: formdata.stepFive
			}
			console.log(params)
			API.uploadFood(params).then(res => {
				console.log('上传菜谱返回信息', res);
				if (res.code == 200) {
					uni.showToast({
						title: '添加成功',
						duration: 2000
					});
					uni.navigateBack({
						delta: 2
					});
				}
			})
		}
	},
	onLoad() {
		let value = uni.getStorageSync('userid');
		if (value) {
			console.log(value);
			this.id = value;
			// if(this.id == ''){
			// 	uni.showModal({
			// 		title: '未登录',
			// 		content: '上传菜谱前请先登录！',
			// 		// showCancel:false
			// 		success: function(res) {
			// 			if (res.confirm) {
			// 				console.log('用户点击确定');
			// 				uni.navigateTo({
			// 					url: '../login/login'
			// 				})
			// 			} else if (res.cancel) {
			// 				console.log('用户点击取消');
			// 			}
			// 		}
			// 	})
			// }
		}
	}
};
</script>

<style lang="scss">
@import '../../static/common/pic.css';
.body-view {
	width: 100%;
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
	align-items: flex-start;
}

.info-table {
	width: 100%;
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
	align-items: flex-start;
	background-color: #ffffff;
}

.uploads {
	width: 92%;
}
.upload-content {
	position: relative;
	width: 100%;
}
.upload-container {
	height: 100%;
	padding: 30rpx;
}
.picture-content {
	margin-bottom: 30rpx;
	// padding: 0 30rpx;
}
.text-upload {
	margin-bottom: 30rpx;
	font-size: 42rpx;
}
.upload-button {
	width: 200rpx;
	height: 200rpx;
	margin-right: 30rpx;
	line-height: 200rpx;
	font-size: 80rpx;
	color: #888;
	background-color: #efeff4;
	text-align: center;
	border-radius: 8rpx;
	border: 1rpx solid #c8c7cc;
}
.image {
	width: 200rpx;
	height: 200rpx;
}

.food-input {
	// width: 100%;
	height: 60rpx;
	line-height: 60rpx;
	border: 1rpx solid #c8c7cc;
	border-radius: 5rpx;
	margin-right: 20rpx;
	padding: 0 20rpx;
}
.step-food {
	margin-bottom: 30rpx;
}
.submit-content {
	position: fixed;
	width: 100%;
	bottom: 0;
}
.submit {
	border-radius: 0;
	background-color: #87cfb5;
}
.materials-word {
	// width: 100%;
	padding: 30rpx;
	border: 1rpx solid #c8c7cc;
}
.in-materials {
	// width: 100%;
	// height: 100rpx;
}
</style>
