<template>
	<view class="detail-content">
		<view class="food-list" v-for="(item, index) in detailList" :key="index">
			<view class="clearfix" @click="goDetail(item.id)">
				<view class="food-image pull-left no-image" v-if="item.image == null">暂无图片</view>
				<view class="food-image pull-left" v-else :style="{ 'background-image': 'url(' + imageUrl + item.image + ')' }"></view>
				<view class="food-word pull-left">
					<view class="food-title">{{ item.name }}</view>
					<view class="food-main">{{ item.username }}</view>
				</view>
			</view>
		</view>
		<view class="no-data" v-if="noData">暂无数据</view>
	</view>
</template>

<script>
	import API from '../../static/js/request.js';

	export default {
		data() {
			return {
				detailList: [],
				imageUrl: 'http://q8pqctivi.bkt.clouddn.com/',
				noData: false,
				pageSize: 10,
				currentPage: 1,
			};
		},
		methods: {
			// 点击跳转至页面详情页
			goDetail: function(foodid) {
				console.log(foodid);
				uni.navigateTo({
					url: '../detail-page/detail-page?foodid=' + foodid
				});
			},

		},
		onLoad(option) {
			console.log(option)
			const param = {
				categoryId: option.id,
				pageSize: this.pageSize,
				currentPage: this.currentPage,

			}
			API.getType(param).then(res => {
				console.log(res);
				this.detailList = res;
				if (this.detailList.length == 0) {
					this.noData = true; // 列表为空时候显示无数据
				}
			});
		}
	};
</script>

<style lang="scss">
	page {
		background-color: #f5f5f5;
	}

	.detail-content {
		width: 100%;
		// padding: 20rpx 25rpx;
	}

	.food-list {
		height: 200rpx;
		padding: 20rpx;
		margin-bottom: 20rpx;
		background-color: #fff;
		// border-radius: 8px;
	}

	.food-image {
		width: 300rpx;
		height: 200rpx;
		background-color: #87cfb5;
		background-repeat: no-repeat;
		background-position: center;
		background-size: cover;
	}

	.food-word {
		width: calc(100% - 330rpx);
		padding-left: 30rpx;
	}

	.food-title {
		font-size: 40rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}

	.food-main {
		padding-top: 20rpx;
		font-size: 32rpx;
		color: #666;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
	}
</style>
